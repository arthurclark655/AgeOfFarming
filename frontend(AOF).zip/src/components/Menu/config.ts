import { MenuEntry } from '@pizzafinance/ui-sdk'

const config: MenuEntry[] = [
  {
    label: 'MAIN PAGE',
    icon: 'HomeIcon',
    href: 'https://ageoffarming.com/',
  },
  {
    label: 'Home',
    icon: 'HomeIcon',
    href: '/',
  },
  {
    label: 'Trade',
    icon: 'TradeIcon',
    items: [
      {
        label: 'Exchange',
        href: 'https://exchange.pancakeswap.finance/#/swap?inputCurrency=0x30423B40afDBCB074C3eF29B17D0F6ff5f33A770&outputCurrency=0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',        
      },
      {
        label: 'Liquidity',
        href: 'https://exchange.pancakeswap.finance/#/add/0x30423B40afDBCB074C3eF29B17D0F6ff5f33A770/0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',
      },
      // {
      //   label: 'DEX',
      //   href: 'https://dex.dragonswap.app/',
      // },
    ],
  },
  {
    label: 'Farms',
    icon: 'FarmIcon',
    href: '/farms',
  },
  {
    label: 'Pools',
    icon: 'PoolIcon',
    href: '/pools',
  },
  {
    label: 'Lottery',
    icon: 'TicketIcon',
    href: '/lottery',
  },
  {
    label: 'Refferals',
    icon: 'TicketIcon',
    href: '/refferals',
  },
  // {
  //   label: 'Comming Soon',
  //   icon: 'PoolIcon',
  //   href: '/staking',
  // },
  // {
  //   label: 'Info',
  //   icon: 'InfoIcon',
  //   items: [
  //     {
  //       label: 'Overview',
  //       href: 'https://info.cheeseswap.app',
  //     },
  //     {
  //       label: 'Tokens',
  //       href: 'https://info.cheeseswap.app/token/0x2cc26dd730f548dc4ac291ae7d84a0c96980d2cb',
  //     },
  //     {
  //       label: 'Pairs',
  //       href: 'https://info.cheeseswap.app/pair/0x8405be915af56589756a275d4894fa9f0ff6ca0f',
  //     },
  //     {
  //       label: 'Accounts',
  //       href: 'https://info.cheeseswap.app/accounts',
  //     },
  //   ],
  // },
  {
    label: 'Info',
    icon: 'InfoIcon',
    // href: 'https://dragonswap.app/Dragonswap%20Whitepaper.pdf',
    href: '#',
  },
  {
    label: 'More',
    icon: 'MoreIcon',
    items: [
      {
        label: 'Github',
        href: 'https://github.com/Ageoffarming',
      },
       {
         label: 'Medium',
        href: 'https://ageoffarming.medium.com/',
       },
      // {
      //   label: 'Token',
      //   href: 'https://bscscan.com/address/0xC32783Ff03562A3B506AA59594Fbd7C08023AB31#code',
      // },
    ],
  },
]

export default config
