import BigNumber from 'bignumber.js'
import { ethers } from 'ethers'

export const approve = async (lpContract, masterChefContract, account) => {
  return lpContract.methods
    .approve(masterChefContract.options.address, ethers.constants.MaxUint256)
    .send({ from: account })
}

export const stake = async (masterChefContract, pid, amount, account, address) => {
  console.log("old amount ".concat(amount))
  console.log("compound param".concat(pid).concat("-").concat(new BigNumber(amount).times(new BigNumber(10).pow(18)).toString()).concat("-").concat(account).concat("-").concat(address))
  return masterChefContract.methods
    .deposit(pid, new BigNumber(amount).times(new BigNumber(10).pow(18)).toString(),address)
    .send({ from: account })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}

export const pastaStake = async (pastaChefContract, amount, account) => {
  return pastaChefContract.methods
    .deposit(new BigNumber(amount).times(new BigNumber(10).pow(18)).toString())
    .send({ from: account })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}

export const pastaStakeBnb = async (pastaChefContract, amount, account) => {
  return pastaChefContract.methods
    .deposit()
    .send({ from: account, value: new BigNumber(amount).times(new BigNumber(10).pow(18)).toString() })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}

export const unstake = async (masterChefContract, pid, amount, account) => {
  return masterChefContract.methods
    .withdraw(pid, new BigNumber(amount).times(new BigNumber(10).pow(18)).toString())
    .send({ from: account })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}

export const pastaUnstake = async (pastaChefContract, amount, account) => {
  if (pastaChefContract.options.address === '0xeBA924b9870dD9cb19b812CfDe5C5289b1a9F3EF') {
    return pastaChefContract.methods
      .emergencyWithdraw()
      .send({ from: account })
      .on('transactionHash', (tx) => {
        return tx.transactionHash
      })
  }
  if (pastaChefContract.options.address === '0xeBA924b9870dD9cb19b812CfDe5C5289b1a9F3EF') {
    return pastaChefContract.methods
      .emergencyWithdraw()
      .send({ from: account })
      .on('transactionHash', (tx) => {
        return tx.transactionHash
      })
  }
  return pastaChefContract.methods
    .withdraw(new BigNumber(amount).times(new BigNumber(10).pow(18)).toString())
    .send({ from: account })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}

export const pastaEmegencyUnstake = async (pastaChefContract, amount, account) => {
  return pastaChefContract.methods
    .emergencyWithdraw()
    .send({ from: account })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}

export const harvest = async (masterChefContract, pid, account, address = "") => {
  return masterChefContract.methods
    // .deposit(pid, '0', address === ""?account:address)
    .withdraw(pid, '0')
    .send({ from: account })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}

export const pastahHarvest = async (pastaChefContract, account) => {
  return pastaChefContract.methods
    .deposit('0')
    .send({ from: account })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}

export const pastahHarvestBnb = async (pastaChefContract, account) => {
  return pastaChefContract.methods
    .deposit()
    .send({ from: account, value: new BigNumber(0) })
    .on('transactionHash', (tx) => {
      return tx.transactionHash
    })
}
