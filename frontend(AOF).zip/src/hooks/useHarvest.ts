import { useCallback, useEffect, useState } from 'react'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import { useDispatch } from 'react-redux'
import { fetchFarmUserDataAsync, updateUserBalance, updateUserPendingReward } from 'state/actions'
import { pastahHarvest, pastahHarvestBnb, harvest } from 'utils/callHelpers'
import { useGettingtime, useMasterchef, usePastaChef } from './useContract'
import { useFarmUser } from '../state/hooks'
import useRefresh from './useRefresh'

export const useHarvest = (farmPid: number) => {
  const dispatch = useDispatch()
  const { account } = useWallet()
  const masterChefContract = useMasterchef()

  const handleHarvest = useCallback(async () => {
    const txHash = await harvest(masterChefContract, farmPid, account)
    dispatch(fetchFarmUserDataAsync(account))
    return txHash
  }, [account, dispatch, farmPid, masterChefContract])

  return { onReward: handleHarvest }
}

export const useAllHarvest = (farmPids: number[]) => {
  const { account } = useWallet()
  const masterChefContract = useMasterchef()

  const handleHarvest = useCallback(async () => {
    const harvestPromises = farmPids.reduce((accum, pid) => {
      return [...accum, harvest(masterChefContract, pid, account)]
    }, [])

    return Promise.all(harvestPromises)
  }, [account, farmPids, masterChefContract])

  return { onReward: handleHarvest }
}

export const usePastaHarvest = (pastaId, isUsingBnb = false) => {
  const dispatch = useDispatch()
  const { account } = useWallet()
  const pastaChefContract = usePastaChef(pastaId)
  const masterChefContract = useMasterchef()

  const handleHarvest = useCallback(async () => {
    if (pastaId === 0) {
      await harvest(masterChefContract, 0, account)
    } else if (isUsingBnb) {
      await pastahHarvestBnb(pastaChefContract, account)
    } else {
      await pastahHarvest(pastaChefContract, account)
    }
    dispatch(updateUserPendingReward(pastaId, account))
    dispatch(updateUserBalance(pastaId, account))
  }, [account, dispatch, isUsingBnb, masterChefContract, pastaChefContract, pastaId])

  return { onReward: handleHarvest }
}

export const useHarvestTime = (farmPid: number) => {
  const { account } = useWallet()
  const masterChefContract = useMasterchef()
  const gettingtimeContract = useGettingtime()
  const [time,setTime] = useState(0)
  const { fastRefresh } = useRefresh()

  useEffect(() => {
    const fetchTime = async () => {
      if(account && time <= 0) {
        const res = await masterChefContract.methods.userInfo(farmPid, account).call()
        const now = await gettingtimeContract.methods.gettingtime().call()
        setTime(res.nextHarvestUntil-now)
      }
    }
    fetchTime()
    if(time > 0)
    {
      setTimeout(()=>{
        setTime(time-1)
      },1000)
    }
  }, [account, masterChefContract, gettingtimeContract, farmPid, time, fastRefresh])

  return time
}