export { default } from './Pasta'
