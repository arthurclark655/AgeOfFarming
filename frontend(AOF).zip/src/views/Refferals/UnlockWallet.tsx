import React, { useState } from 'react'
import styled from 'styled-components'
import { Heading, Card, CardBody, Link, Button } from '@pizzafinance/ui-sdk'
import useI18n from 'hooks/useI18n'
import { useWallet } from '@binance-chain/bsc-use-wallet';
import { useTotalReferralCommissions, useTotalReferrals } from '../../hooks/useTokenBalance'
import UnlockButton from '../../components/UnlockButton';


const StyledUnlockWalletCard = styled(Card)`
  background-image: url('/images/cardback_home.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 5px 0;
  border-radius: 0;
  text-align: center;
  width: auto !important;
  margin-left: 0;
  height: 360px;
  ${({ theme }) => theme.mediaQueries.sm} {
    height: 330px;
    /*width: calc(200% - 365px) !important;*/
    /*margin-left: calc(-100% + 365px);*/
  }
  & *{
    font-family: "Trajan Pro";
    font-weight: bold;
  }
`

const StyledRefferalsCard = styled(Card)`
  background-image: url('/images/cardback_home.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 5px 0;
  border-radius: 0;
  text-align: center;
  width: auto !important;
  margin-left: 0;
  padding: 20px;
  height: auto;
  ${({ theme }) => theme.mediaQueries.sm} {
    min-height: 300px;
    height: auto;
    /*width: calc(200% - 365px) !important;*/
    /*margin-left: calc(-100% + 365px);*/
  }
  & *{
    font-family: "Trajan Pro";
    font-weight: bold;
  }
`
const Block = styled.div`
 margin-top: 1em;
`
const CardImage = styled.img`
  // box-shadow: -8px 8px 0 0 rgba(201,157,55,0.4);
`
const Label = styled.div`
  color: ${({ theme }) => theme.colors.primary};
  font-size: 14px;
`
const Actions = styled.div`
 display: flex;
 position: absolute;
 bottom: 12%;
 width: 88%;
 button {
   flex: 1 0 50%;
 }
 @media (max-width: 768px) {
  display: block;
 }
 `
 const Row = styled.div`
  display: flex;
  flex-direction: row;
`
const Left = styled.div`
  padding-top: 5%;
  width: 30%;
`
const Center = styled.div`
  width: 40%;
`
const Right = styled.div`
  padding-top: 5%;
  width: 30%;
`

const Inform = styled.div`
  font-size: 12px;
  color: #761714;
  padding: 10px;
  text-align: center;
  @media (max-width: 768px) {
    margin-top: 40px;
  }
`;

const RefferalLink = styled.div`
  display: flex;
  flex-direction: row;
  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const RefferalLinkDiv = styled.div`
  width: 70%;
  padding: 20px;
  @media (max-width: 768px) {
    width: 100%;
  }
`;

const RefferalCopyDiv = styled.div`
  width: 30%;
  display: flex;
  align-items: center;
  justify-content: center;
  @media (max-width: 768px) {
    width: 100%;
    margin-bottom: 20px;
  }
`;

const FarmedStakingCard = () => {
  const TranslateString = useI18n()
  const { account } = useWallet()
  const myTotalReferrals = useTotalReferrals(account);
  const TotalReferrals = myTotalReferrals.toNumber();
  const myTotalReferralCommissions = useTotalReferralCommissions(account);
  const TotalReferralCommissionsValue = myTotalReferralCommissions.toNumber() === 0?'0':((myTotalReferralCommissions.toNumber()/1000000000000000000)).toLocaleString('en-US', {minimumFractionDigits: 3})
  const refferalsLink = "https://farm.ageoffarming.com/?ref=".concat(btoa(account));
  const [copyText, setCopyText] = useState("Copy")

  const handleCopy = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(refferalsLink);
      setCopyText("Copied");
      setTimeout(function() {
        setCopyText("Copy");
      }, 1000);
    }
  };
  
  return (
    <>
    {account? 
      (
        <StyledRefferalsCard>
          <Heading mb="20px" color="#7f080e" style={{ margin: "20px auto 10px"}}>
            {TranslateString(550, 'Total Referrals')}
          </Heading>
          <Label>{TotalReferrals}</Label>
          <Heading mb="20px" color="#7f080e" style={{ margin: "20px auto 10px"}}>
            {TranslateString(550, 'Total Referral Commissions')}
          </Heading>
          <Label>{TotalReferralCommissionsValue}</Label>
          <Heading mb="20px" color="#7f080e" style={{ margin: "20px auto 10px"}}>
            {TranslateString(550, 'Your Referral Link')}
          </Heading>
          <RefferalLink>
            <RefferalLinkDiv>
              <Label style={{wordWrap: 'break-word', textTransform: 'none'}}>{refferalsLink}</Label>
            </RefferalLinkDiv>
            <RefferalCopyDiv>
              <Button className='imgBtn' onClick={handleCopy}>{copyText}</Button>
            </RefferalCopyDiv>
          </RefferalLink>
        </StyledRefferalsCard>
      ) : (
        <StyledUnlockWalletCard>
          <CardBody>
            <Heading mb="20px" color="#7f080e" style={{width: "min(100%,14em)", margin: "20px auto"}}>
              {TranslateString(550, 'Unlock wallet')}
            </Heading>
            <Block>
              <Row>
                <Left>
                  <Label>{TranslateString(552, '')}</Label>
                </Left>
                <Center>
                  <CardImage src="/images/ticket-bg.png" alt="AOF Lottery logo"/>
                </Center>
                <Right>
                  <Label>{TranslateString(554, '')}</Label>
                </Right>
              </Row>
            </Block>
            <Inform>Unlock wallet to get your unique referral link</Inform>
            <Actions>
              <div style={{margin:"0 auto"}}>
                <UnlockButton className="imgBtn"/>
              </div>
            </Actions>
          </CardBody>
        </StyledUnlockWalletCard>
      )
    }
    </>
    
  )
}

export default FarmedStakingCard
