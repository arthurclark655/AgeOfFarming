import React, { useMemo, useEffect, useState, useCallback } from 'react'
import BigNumber from 'bignumber.js'
import styled from 'styled-components'
import { provider } from 'web3-core'
import { getContract } from 'utils/erc20'
import { Button, Flex, Heading, Text, useModal } from '@pizzafinance/ui-sdk'
import { Farm } from 'state/types'
import { useFarmFromPid, useFarmUser } from 'state/hooks'
import useI18n from 'hooks/useI18n'
import UnlockButton from 'components/UnlockButton'
import { useApprove } from 'hooks/useApprove'
import StakeAction from './StakeAction'
import HarvestAction from './HarvestAction'
import TimeModal from '../TimeModal'
import { useHarvestTime } from '../../../../hooks/useHarvest'
import "./FarmCard.scss";

const Action = styled.div`
  padding-top: 0px;
  margin-left: -5%;
  ${({ theme }) => theme.mediaQueries.sm}{
    margin: 0;
  }
`

const TimeButton = styled.button`
  background: transparent;
  padding: 0;
  border: none !important;
  outline: none !important;
  cursor: pointer;
`
export interface FarmWithStakedValue extends Farm {
  apy?: BigNumber
}

interface FarmCardActionsProps {
  farm: FarmWithStakedValue
  ethereum?: provider
  account?: string
}

const CardActions: React.FC<FarmCardActionsProps> = ({ farm, ethereum, account }) => {
  const TranslateString = useI18n()
  const [requestedApproval, setRequestedApproval] = useState(false)
  const { pid, lpAddresses, tokenAddresses, isTokenOnly, depositFeeBP } = useFarmFromPid(farm.pid)
  const { allowance, tokenBalance, stakedBalance, earnings } = useFarmUser(pid)
  const lpAddress = lpAddresses[process.env.REACT_APP_CHAIN_ID]
  const tokenAddress = tokenAddresses[process.env.REACT_APP_CHAIN_ID];
  const lpName = farm.lpSymbol.toUpperCase()
  const isApproved = account && allowance && allowance.isGreaterThan(0)

  const lpContract = useMemo(() => {
    if(isTokenOnly){
      return getContract(ethereum as provider, tokenAddress);
    }
    return getContract(ethereum as provider, lpAddress)
  }, [ethereum, lpAddress, tokenAddress, isTokenOnly])
  const harvestTime = useHarvestTime(pid)

  const [onPresentTime] = useModal(<TimeModal pid={farm.pid}/>)

  const { onApprove } = useApprove(lpContract)

  const handleApprove = useCallback(async () => {
    try {
      setRequestedApproval(true)
      await onApprove()
      setRequestedApproval(false)
    } catch (e) {
      console.error(e)
    }
  }, [onApprove])

  const renderApprovalOrStakeButton = () => {
    return isApproved ? (
      <StakeAction stakedBalance={stakedBalance} tokenBalance={tokenBalance} tokenName={lpName} pid={pid} depositFeeBP={depositFeeBP} />
    ) : (
      <Button mt="8px" fullWidth disabled={requestedApproval} onClick={handleApprove} className="imgBtn">
       {/* <Button mt="8px" fullWidth disabled={requestedApproval} className="imgBtn"> */}
        {TranslateString(999, 'Approve Contract')}
      </Button>
    )
  }

  return (
    <Action>
      <Flex justifyContent="space-between" mb="10px">
        <Flex>
          <Text bold textTransform="uppercase" color="primary" fontSize="22px" pr="3px" style={{fontFamily: "Por Siempre Gti"}}>
            {/* TODO: Is there a way to get a dynamic value here from useFarmFromSymbol? */}
            AOF
          </Text>
          <Text bold textTransform="uppercase" color="primary" fontSize="22px" style={{fontFamily: "Por Siempre Gti"}}>
            {TranslateString(999, 'Earned')}
          </Text>
        </Flex>
	      {
          (stakedBalance.toNumber() > 0 && harvestTime >=0 ) &&
          (
            <TimeButton onClick={onPresentTime} className="timebtn">
            {/* <TimeButton> */}
              <span className="iconify" data-icon="clarity:alarm-clock-outline-badged">.</span>
            </TimeButton>
          )
        }
      </Flex>
      <HarvestAction earnings={earnings} pid={pid} />
      <Flex>
        <Text bold textTransform="uppercase" color="primary" fontSize="22px" pr="3px" style={{fontFamily: "Por Siempre Gti"}}>
          {lpName}
        </Text>
        <Text bold textTransform="uppercase" color="primary" fontSize="22px" style={{fontFamily: "Por Siempre Gti"}}>
          {TranslateString(999, 'Staked')}
        </Text>
      </Flex>
      {!account ? <UnlockButton mt="-5px"/> : renderApprovalOrStakeButton()}
    </Action>
  )
}

export default CardActions
