import React, { useMemo, useState } from 'react'
import BigNumber from 'bignumber.js'
import styled, { keyframes } from 'styled-components'
import { Flex, Text, Skeleton } from '@pizzafinance/ui-sdk'
import { communityFarms } from 'config/constants'
import { Farm } from 'state/types'
import { provider } from 'web3-core'
import useI18n from 'hooks/useI18n'
import ExpandableSectionButton from 'components/ExpandableSectionButton'
import { QuoteToken } from 'config/constants/types'
import DetailsSection from './DetailsSection'
import CardHeading from './CardHeading'
import CardActionsContainer from './CardActionsContainer'
import ApyButton from './ApyButton'
import './FarmCard.scss';

export interface FarmWithStakedValue extends Farm {
  apy?: BigNumber  
}

const RainbowLight = keyframes`
	0% {
		background-position: 0% 50%;
	}
	50% {
		background-position: 100% 50%;
	}
	100% {
		background-position: 0% 50%;
	}
`

const StyledCardAccent = styled.div`
  background: linear-gradient(
    45deg,
    rgba(255, 0, 0, 1) 0%,
    rgba(255, 154, 0, 1) 10%,
    rgba(208, 222, 33, 1) 20%,
    rgba(79, 220, 74, 1) 30%,
    rgba(63, 218, 216, 1) 40%,
    rgba(47, 201, 226, 1) 50%,
    rgba(28, 127, 238, 1) 60%,
    rgba(95, 21, 242, 1) 70%,
    rgba(186, 12, 248, 1) 80%,
    rgba(251, 7, 217, 1) 90%,
    rgba(255, 0, 0, 1) 100%
  );
  background-size: 300% 300%;
  animation: ${RainbowLight} 2s linear infinite;
  border-radius: 16px;
  filter: blur(6px);
  position: absolute;
  top: -2px;
  right: -2px;
  bottom: -2px;
  left: -2px;
  z-index: -1;
`

const HelpDiv = styled.div`
  display: inline-block;
  position: relative;
  & > a {
    position: relative;
    top: 4px;
    left: 4px;
  }
  & > .tooltip{
    display: none;
    background: rgba(0,0,0,0.8);
    position: absolute;
    width: 160px;
    left: 135%;
    padding: 10px;
    border-radius: 10px;
    top: -35px;
  }
  &:hover > .tooltip{
    display: block;
  }
`

const FCard = styled.div`
  align-self: baseline;
  background: ${(props) => props.theme.card.background};
  background-image: url('/images/cardback_farms.png');
  background-size: 100% 560px;
  background-repeat: no-repeat;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  padding: 13% 20%;
  padding-right: 22%;
  position: relative;
  text-align: center;
  ${({ theme }) => theme.mediaQueries.xs} {
    background-size: 100% 560px;
  }
`
const BottomBar = ()=>{
  return (<img alt="bottom" style={{width: "100%",position: "absolute",left: "0",bottom: "-12px"}} src='/images/cardbackbottom_farm.png'/>);
}

const Divider = styled.div`
  background-color: ${({ theme }) => theme.colors.borderColor};
  height: 1px;
  margin: 28px auto;
  width: 100%;
`

const ExpandingWrapper = styled.div<{ expanded: boolean }>`
  height: ${(props) => (props.expanded ? '100%' : '0px')};
  overflow: hidden;
`

interface FarmCardProps {
  farm: FarmWithStakedValue
  removed: boolean
  pizzaPrice?: BigNumber
  bnbPrice?: BigNumber
  ethereum?: provider
  account?: string
}

const FarmCard: React.FC<FarmCardProps> = ({ farm, removed, pizzaPrice, bnbPrice, ethereum, account }) => {
  const TranslateString = useI18n()

  const [showExpandableSection, setShowExpandableSection] = useState(false)

  const isCommunityFarm = communityFarms.includes(farm.tokenSymbol)
  // We assume the token name is coin pair + lp e.g. PIZZA-BNB LP, LINK-BNB LP,
  // NAR-PIZZA LP. The images should be pizza-bnb.svg, link-bnb.svg, nar-pizza.svg
  const farmImage = farm.lpSymbol.split(' ')[0].toLocaleLowerCase()

  const totalValue: BigNumber = useMemo(() => {
    if (!farm.lpTotalInQuoteToken) {
      return null
    }
    if (farm.quoteTokenSymbol === QuoteToken.BNB) {
      return bnbPrice.times(farm.lpTotalInQuoteToken)
    }
    if (farm.quoteTokenSymbol === QuoteToken.PIZZA) {
      return pizzaPrice.times(farm.lpTotalInQuoteToken)
    }
    return farm.lpTotalInQuoteToken
  }, [bnbPrice, pizzaPrice, farm.lpTotalInQuoteToken, farm.quoteTokenSymbol])

  const totalValueFormated = totalValue
    ? `$${Number(totalValue).toLocaleString(undefined, { maximumFractionDigits: 0 })}`
    : '-'

  const lpLabel = farm.lpSymbol && farm.lpSymbol.toUpperCase().replace('PIZZAFINANCE', '')
  const earnLabel = farm.dual ? farm.dual.earnLabel : 'AOF'
  const farmAPY = farm.apy && farm.apy.times(new BigNumber(100)).toNumber().toLocaleString('en-US').slice(0, -1)
  
  const { quoteTokenAdresses, quoteTokenSymbol, tokenAddresses } = farm

  return (
    <FCard>
      {farm.tokenSymbol === 'AOF' && <StyledCardAccent />}
      <CardHeading
        lpLabel={lpLabel}
        multiplier={farm.multiplier}
        isCommunityFarm={isCommunityFarm}
        farmImage={farmImage}
        tokenSymbol={farm.tokenSymbol}
        depositFee={farm.depositFeeBP}
      />
      

    {!removed && (
        <Flex justifyContent="space-between" alignItems="center">
          <Text bold style={{ fontFamily:"Por Siempre Gti", color: "black" }} fontSize="20px">{TranslateString(352, 'APY')}:</Text>
          <Text bold style={{ display: 'flex', alignItems: 'center',fontFamily:"Por Siempre Gti",color: "black" }} fontSize="20px">
            {farm.apy ? (
              <>
                <ApyButton
                  lpLabel={lpLabel}
                  quoteTokenAdresses={quoteTokenAdresses}
                  quoteTokenSymbol={quoteTokenSymbol}
                  tokenAddresses={tokenAddresses}
                  pizzaPrice={pizzaPrice}
                  apy={farm.apy}
                />
                {farmAPY}%
                {/* {0}% */}
              </>
            ) : (
              <Skeleton height={24} width={80} />
            )}
          </Text>
        </Flex>
        
      )}
      <Flex justifyContent='space-between'>
        <Text style={{ fontFamily:"Por Siempre Gti", color: "black", fontSize: '24px' }}>{TranslateString(10001, 'Deposit Fee')}:</Text>
        {farm.apy? (
          <Text bold style={{ fontFamily:"Por Siempre Gti", color: "black", fontSize: '24px' }}>{(farm.depositFeeBP / 100)} %</Text>
        ) : (
          <Skeleton height={24} width={80} />
        ) }
      </Flex>
      <Flex justifyContent='space-between'>
        <Text style={{ fontFamily:"Por Siempre Gti", color: "black", fontSize: '15px' }}>
          Harvest Lockup
          <HelpDiv>
            <a href="https://ageoffarmingdefi.gitbook.io/age-of-farming" rel="noreferrer" target="_blank">
              <span className="iconify" data-icon="clarity:help-outline-badged" />
            </a>
            <span className="tooltip">
              <Text color="gold">How soon you harvest or compound again</Text>
            </span>
          </HelpDiv>
        </Text>
        {farm.apy? (
          <Text bold style={{ fontFamily:"Por Siempre Gti", color: "black", fontSize: '15px' }}>{(farm.harvestInterval / 3600)} hours</Text>
        ) : (
          <Skeleton height={24} width={80} />
        ) }
      </Flex>
      <Flex justifyContent="space-between">
        <Text bold style={{fontFamily:"Por Siempre Gti",color: "black"}} fontSize="20px">{TranslateString(318, 'Earn')}:</Text>
        <Text bold style={{fontFamily:"Por Siempre Gti",color: "black"}} fontSize="20px">{earnLabel}</Text>
      </Flex>
      <CardActionsContainer farm={farm} ethereum={ethereum} account={account} />
      <ExpandableSectionButton
        onClick={() => setShowExpandableSection(!showExpandableSection)}
        expanded={showExpandableSection}
      />
      <ExpandingWrapper expanded={showExpandableSection}>
        <DetailsSection
          removed={removed}
          bscScanAddress={`https://bscscan.com/address/${farm.lpAddresses[process.env.REACT_APP_CHAIN_ID]}`}
          totalValueFormated={totalValueFormated}
          lpLabel={lpLabel}
          quoteTokenAdresses={quoteTokenAdresses}
          quoteTokenSymbol={quoteTokenSymbol}
          tokenAddresses={tokenAddresses}
        />
      </ExpandingWrapper>
      <BottomBar/>
    </FCard>
  )
}

export default FarmCard
