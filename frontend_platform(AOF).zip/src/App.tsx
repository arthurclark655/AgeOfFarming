import React, { useEffect, Suspense, lazy } from 'react'
import { HashRouter as Router, Redirect, Route, Switch } from 'react-router-dom'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import { ResetCSS } from '@pizzafinance/ui-sdk'
import BigNumber from 'bignumber.js'
import { useFetchPublicData } from './state/hooks'
import GlobalStyle from './style/Global'
import Menu from './components/Menu'
import PageLoader from './components/PageLoader'
// import NftGlobalNotification from './views/Nft/components/NftGlobalNotification'
import Pools from './views/Pools'
import TopBar from './components/TopBar'
import "./style.scss";

// Route-based code splitting
// Only pool is included in the main bundle because of it's the most visited page'
const Home = lazy(() => import('./views/Home'))
const Farms = lazy(() => import('./views/Farms'))
const Lottery = lazy(() => import('./views/Lottery'))
const Refferals = lazy(() => import('./views/Refferals'))
const Ifos = lazy(() => import('./views/Ifos'))
const NotFound = lazy(() => import('./views/NotFound'))
// const Nft = lazy(() => import('./views/Nft'))

// This config is required for number formating
BigNumber.config({
  EXPONENTIAL_AT: 1000,
  DECIMAL_PLACES: 80,
})

const App: React.FC = () => {
  const { account, connect } = useWallet()
  useEffect(() => {
    if (!account && window.localStorage.getItem('accountStatus')) {
      connect('injected')
    }
  }, [account, connect])

  useFetchPublicData()

  return (
    <Router basename="/">
      <ResetCSS />
      {/* <GlobalStyle /> */}
      <Menu>
        <Suspense fallback={<PageLoader />}>
          <TopBar />
          <Switch>
            <Route path="/" exact component={Home} />
            <Route exact path="/farms" component={Farms} />
            <Route exact path="/pools">
              <Farms tokenMode/>
            </Route>
            <Route exact path="/lottery">
              <Lottery />
            </Route>
            <Route exact path="/refferals">
              <Refferals />
            </Route>
            <Route exact path="/ifo">
              <Ifos />
            </Route>
            <Route exact path="/staking">
              <Pools />
            </Route>
            {/* <Route path="/pasta">
              <Redirect to="/pools" />
            </Route> */}
            {/* 404 */}
            <Route component={NotFound} />
          </Switch>
        </Suspense>
      </Menu>
    </Router>
  )
}

export default React.memo(App)
