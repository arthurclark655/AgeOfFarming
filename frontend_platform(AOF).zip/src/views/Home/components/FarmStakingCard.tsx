import React, { useState, useCallback } from 'react'
import styled from 'styled-components'
import { Heading, Card, CardBody, Button, PizzaTheme, BackgroundImage } from '@pizzafinance/ui-sdk'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import useI18n from 'hooks/useI18n'
import { useAllHarvest } from 'hooks/useHarvest'
import useFarmsWithBalance from 'hooks/useFarmsWithBalance'
import UnlockButton from 'components/UnlockButton'
import PizzaHarvestBalance from './PizzaHarvestBalance'
import PizzaWalletBalance from './PizzaWalletBalance'

const StyledFarmStakingCard = styled(Card)`
  background-image: url('/images/cardback_home.png');
  background-repeat: no-repeat;
  background-size:100% 100%;
  border-radius: 0;
  text-align: center;
  height: 360px;
  ${({ theme }) => theme.mediaQueries.sm}{
    height: 320px;
  }
  & *{
    font-family: "Trajan Pro";
    font-weight: bold;
  }
`

const Block = styled.div`
  margin-top: -25px;
  z-index: 1;
  position: relative;
`

const CardImage = styled.img`
  // box-shadow: -10px 10px 0 0 #d69f42;
  border-radius: 50%;
  margin-top: 5px;
`

const Label = styled.div`
  color: ${({ theme }) => theme.colors.primary};
  font-size: 16px;
`

const Actions = styled.div`
  position: absolute;
  bottom: 12%;
  width: 88%;
`

const Row = styled.div`
  display: flex;
  flex-direction: row;
`

const Left = styled.div`
  width: 45%;
  margin-right: 10%;
`

const Right = styled.div`
  width: 45%;
`

const FarmedStakingCard = () => {
  const [pendingTx, setPendingTx] = useState(false)
  const { account } = useWallet()
  const TranslateString = useI18n()
  const farmsWithBalance = useFarmsWithBalance()
  const balancesWithValue = farmsWithBalance.filter((balanceType) => balanceType.balance.toNumber() > 0)

  const { onReward } = useAllHarvest(balancesWithValue.map((farmWithBalance) => farmWithBalance.pid))

  const harvestAllFarms = useCallback(async () => {
    setPendingTx(true)
    try {
      await onReward()
    } catch (error) {
      // TODO: find a way to handle when the user rejects transaction or it fails
    } finally {
      setPendingTx(false)
    }
  }, [onReward])

  return (
    <StyledFarmStakingCard>
      <CardBody>
        <Heading size="lg" mb="24px"  color="#7f080e" style={{width: "100%", margin: "10px auto", fontFamily: "Trajan Pro", marginTop: '10px' }}>
          {TranslateString(542, 'Farms & Staking')}
        </Heading>
        <CardImage src="/images/cardBack.png" alt="AOF logo" width={70}/>
        <Block>
          <Row>
            <Left>
              <PizzaHarvestBalance />              
              <Label>{TranslateString(544, 'AOF to Harvest')}</Label>
            </Left>
            <Right>
              <PizzaWalletBalance />         
              <Label>{TranslateString(546, 'AOF in Wallet')}</Label>
            </Right>
          </Row>
        </Block>
        <Actions>
          {account ? (
            <Button
              className="imgBtn"
              id="harvest-all"
              disabled={balancesWithValue.length <= 0 || pendingTx}              
              // onClick={harvestAllFarms}
              fullWidth
            >
              {pendingTx
                ? TranslateString(548, 'Collecting AOF')
                : TranslateString(999, `Harvest all (${balancesWithValue.length})`)}
                {/* : TranslateString(999, `Harvest all (0)`)} */}
            </Button>
          ) : (
            <UnlockButton className="imgBtn"/>
          )}
        </Actions>
      </CardBody>
    </StyledFarmStakingCard>
  )
}

export default FarmedStakingCard
