export default {
  cake: {
    56: '0x30423B40afDBCB074C3eF29B17D0F6ff5f33A770',
    97: '',
  },
  masterChef: {
    56: '0x97Ba186E7E2F462b6A9141fbb72bCEf69BA79788',
    97: '',
  },
  wbnb: {
    56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    97: '',
  },
  lottery: {
    // 56: '0x8c89b19f1dBE30625eF6e88DfAe9Adb66B7561cb',
    56: '0x77013268112AF128FAbC422a70656716B36D29D2',
    97: '',
  },
  lotteryNFT: {
    // 56: '0xe763Ab864172c8fcf23faa277585d6283111792e',
    56: '0x3eAD48a871dd3EA063Ace87eEb94444db8D25c0c',
    97: '',
  },
  mulltiCall: {
    56: '0x1ee38d535d541c55c9dae27b12edf090c608e6fb',
    97: '0x67ADCB4dF3931b0C5Da724058ADC2174a9844412',
  },
  busd: {
    56: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
    97: '',
  },
  pancakepair1: {
    56: '0xE9bdEDA655699D7176e22C55f06C00461F0e98aF',
    97: '',
  },
  pancakepair2: {
    56: '0x4Be36eE456c602dC119B763A2F867A3cdCfF0939',
    97: '',
  },
  referral: {
    56: '0xD525eD92a7Dd82d50cda77D160ca8bDa35463927',
    97: '',
  },
  gettingtime: {
    56: '0xdE2488b53468eBF4aeF566719817dDe0231aF466',
    97: '',
  },
}
